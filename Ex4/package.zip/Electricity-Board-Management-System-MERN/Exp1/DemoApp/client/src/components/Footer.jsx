import React from "react";

function Footer(){
    return(
        <div>
        <footer className="text-center py-6 bg-gray-800 text-white">
            <p>&copy; 2025  Online Attendance Database. All rights reserved.</p>
        </footer>
        </div>
    )
}
export default Footer